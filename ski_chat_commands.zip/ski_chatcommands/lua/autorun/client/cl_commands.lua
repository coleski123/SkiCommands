include("autorun/ski_commands_config.lua")
hook.Add( "OnPlayerChat", "changelog", function( ply, text )
	if ply == LocalPlayer() and text == skicommands.config.changelogcommand then
		local serverprefix4 = skicommands.config.serverprefix
		local prefixcolor4 = skicommands.config.prefixcolor
		local linkcolor4 = skicommands.config.linkcolor
		chat.AddText( prefixcolor4, serverprefix4, linkcolor4, skicommands.config.changelog )
		return true
	end
end )

hook.Add( "OnPlayerChat", "shop", function( ply, text )
if ply == LocalPlayer() and text == skicommands.config.shopcommand then
		local serverprefix3 = skicommands.config.serverprefix
		local prefixcolor3 = skicommands.config.prefixcolor
		local linkcolor3 = skicommands.config.linkcolor
		chat.AddText( prefixcolor3, serverprefix3, linkcolor3, skicommands.config.shop )
		return true
	end
end)

hook.Add( "OnPlayerChat", "discord", function( ply, text )
if ply == LocalPlayer() and text == skicommands.config.discordcommand then
		local serverprefix2 = skicommands.config.serverprefix
		local prefixcolor2 = skicommands.config.prefixcolor
		local linkcolor2 = skicommands.config.linkcolor
		chat.AddText( prefixcolor2, serverprefix2, linkcolor2, skicommands.config.discord )
		return true
	end
end)

hook.Add( "OnPlayerChat", "forums", function( ply, text )
if ply == LocalPlayer() and text == skicommands.config.forumscommand then
		local serverprefix1 = skicommands.config.serverprefix
		local prefixcolor1 = skicommands.config.prefixcolor
		local linkcolor1 = skicommands.config.linkcolor
		chat.AddText( prefixcolor1, serverprefix1, linkcolor1, skicommands.config.forums )
		return true
	end
end)

hook.Add( "OnPlayerChat", "steamgroup", function( ply, text )
if ply == LocalPlayer() and text == skicommands.config.steamgroupcommand then
		local serverprefix = skicommands.config.serverprefix
		local prefixcolor = skicommands.config.prefixcolor
		local linkcolor = skicommands.config.linkcolor
		chat.AddText( prefixcolor, serverprefix, linkcolor, skicommands.config.steamgroup )
		return true
	end
end)

hook.Add( "OnPlayerChat", "collection", function( ply, text )
if ply == LocalPlayer() and text == skicommands.config.collectioncommand then
		local serverprefixsteam = skicommands.config.serverprefix
		local prefixcolorsteam = skicommands.config.prefixcolor
		local linkcolorsteam = skicommands.config.linkcolor
		chat.AddText( prefixcolorsteam, serverprefixsteam, linkcolorsteam, skicommands.config.collection )
		return true
	end
end)