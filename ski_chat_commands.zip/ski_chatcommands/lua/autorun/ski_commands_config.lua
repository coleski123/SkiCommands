skicommands = skicommands or {}
skicommands.config = {}

skicommands.config.serverprefix = "[SHRP] " --Your command prefix Eg. [SHRP] Google.com
skicommands.config.prefixcolor = Color(184, 48, 58) --What color do you want the prefix to be
skicommands.config.linkcolor = Color(255,255,255) --What color do you want the link to be

skicommands.config.discordcommand = "!discord" --Your custom command [MAKE SURE ITS UNIQUE]
skicommands.config.discord = "https://discord.gg/4snYQYXXbv" --Your discord invite link

skicommands.config.shopcommand = "!shop" --Your custom command [MAKE SURE ITS UNIQUE]
skicommands.config.shop = "https://sockhutrp.com/shop/categories/sockhutrp" --Your store link

skicommands.config.forumscommand = "!forums" --Your custom command [MAKE SURE ITS UNIQUE]
skicommands.config.forums = "https://sockhutrp.com/forum" --Your forums link

skicommands.config.changelogcommand = "!changelog" --Your custom command [MAKE SURE ITS UNIQUE]
skicommands.config.changelog = "https://sockhutrp.com/changelog/categories/1" --Your changelog link

skicommands.config.steamgroupcommand = "!steamgroup" --Your custom command [MAKE SURE ITS UNIQUE]
skicommands.config.steamgroup = "N/A" --Your steam froup link

skicommands.config.collectioncommand = "!collection" --Your custom command [MAKE SURE ITS UNIQUE]
skicommands.config.collection = "https://steamcommunity.com/sharedfiles/filedetails/?id=2578094784" --Your servers workshop collection