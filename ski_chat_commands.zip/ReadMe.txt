INSTALL PATH
YOURSERVER\garrysmod\addons

My Discord: https://discord.gg/at8yqRQ